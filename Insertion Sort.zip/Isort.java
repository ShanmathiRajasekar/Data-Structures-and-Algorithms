//Shanmathi Rajasekar

//ID - srajase1@uncc.edu
//800# - 800966697
// Data Structures and Algorithm Programming 1

//*********************************************************************************************************************
//importing java packages
import java.util.*; 
import java.io.*; 
public class Isort
{
   public static void main(String args []) 
      {      
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));//it reads file name from command prompt 
      //and convert into bytes and then  into Unicode characters      
      String input = null;
      String[] input_array = null;
      int len =0, i=0;
      double insert=0; // declared in double (this works even for sorting of decimal values)
        
      try 
      { 
         BufferedReader buff = new BufferedReader(new FileReader(args[0])); //it reads file name from command prompt 
         //and convert into bytes and then  into Unicode characters      
         StringBuffer stringbuffer = new StringBuffer("");  
         while((input = buff.readLine()) != null)// checks condition- whether element is present in input file       
              {            
              stringbuffer.append(input);//if some more elements are present, it will append numbers 
              }
         input_array = stringbuffer.toString().split(";"); // contents of the file are converted into String, then ; is removed
         len = input_array.length; //determines array length
         double[] new_arr = new double[len];
         ArrayList<Double> al = new ArrayList<Double>(); // As using Array list is efficient
         for(int p=0; p<len; p++)   
            {
            new_arr[p] = Double.parseDouble(input_array[p].trim());//stored as double. Thus sorting of floating point numbers is also possible
            al.add(i,new_arr[p]); //adding sorted inputs to new array
            }
         int n = al.size(); //size of array list is in variable n  	
	    	for (i = 1; i < n; i++) { //iteration starts from key (second element)
			double sort_value =  al.get(i); //For every iteration the sort_value changes- gets from al
			int j = i - 1; // this is used to compare with previous element
         while ((j >=0) && al.get(j) > sort_value)//insertion sort comparison- the key and previous values are compared 
              {
              al.set(j + 1, al.get(j)); //if first element is greater than key, then the values should exchange its positon
		   	  j=j-1;   
			     }
          al.set(j+1,sort_value);
		  }
         
         // answer.txt file is created. The sorted output is copied to 'answer.txt' file separated by semicolon.
         BufferedWriter buff1 = new BufferedWriter(new FileWriter("answer.txt"));
         for(i=0; i<al.size(); i++)
            {
            if(i<(al.size()-1))//';' is added inbetween numbers. For last element ; is not added
               buff1.write(al.get(i).toString()+"; "); // with semicolon
            else
               buff1.write(al.get(i).toString()); //without semicolon
            }
         buff1.close();
      }
      
      catch(Exception e) // Error handling and debugging
          {
          System.out.println("Unable to open " + e); 
          }
   } 
}